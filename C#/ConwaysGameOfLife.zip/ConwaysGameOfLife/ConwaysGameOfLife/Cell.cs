﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConwaysGameOfLife
{
    internal class Cell
    {
        public bool CurrGen { set; get; }
        public bool NextGen { set; get; }

        public Cell ()
        {
            CurrGen = false;
            NextGen = false;
        }


    }
}
