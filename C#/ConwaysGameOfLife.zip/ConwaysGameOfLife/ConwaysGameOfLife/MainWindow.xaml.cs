﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ConwaysGameOfLife
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        int GameColumns;
        int GameRows;
        Game game;


        public MainWindow()
        {
            InitializeComponent();
            newGame();
        }

        public void newGame()
        {
            GameColumns = 20;
            GameRows = 20;
            game = new Game(GameColumns, GameRows);
            CurrGen.Text = "Generation: " + game.GenCnt.ToString();

            drawBoard();
        }

        private void drawBoard()
        {
            for (int i = 0; i < GameColumns; i++)
            {
                for (int j = 0; j < GameRows; j++)
                {
                    drawCell(i, j);
                }
            }
        }

        private void drawCell(int i, int j)
        {
            int Height = (int)GameCanvas.Height / GameRows;
            int Width = (int)GameCanvas.Width / GameColumns;

            if (game.GetCurr(i,j))
            {
                Border br = PutRect3D(i * Height, j * Width, Width, Height, 2, Colors.Black);
                GameCanvas.Children.Add(br);
            }
            else
            {
                Border br = PutRect3D(i * Height, j * Width, Width, Height, 2, Colors.Silver);
                GameCanvas.Children.Add(br);
            }

        }

        private Border PutRect3D(double top, double left, double w, double h, int tick, Color c)
        {
            Border br = Rect3D(w, h, tick, c);


            Canvas.SetLeft(br, left); // same like ExBr.SetValue(Canvas.LeftProperty, 0.0);
            Canvas.SetTop(br, top);

            return br;

        }


        private Border Rect3D(double w, double h, int tick, Color c)
        {
            Rectangle r = new Rectangle();

            r.Height = h - 2 * tick;
            r.Width = w - 2 * tick;
            r.Fill = new SolidColorBrush(c);


            Border InnerBr = new Border();
            InnerBr.BorderThickness = new Thickness(0, 0, tick, tick);
            InnerBr.BorderBrush = Brushes.Black;

            InnerBr.Child = r;

            Border ExBr = new Border();
            ExBr.BorderThickness = new Thickness(tick, tick, 0, 0);
            ExBr.BorderBrush = Brushes.White;

            ExBr.Child = InnerBr;
            ExBr.Height = h;
            ExBr.Width = w;

            return ExBr;

        }

        private void BtnMain_Click(object sender, RoutedEventArgs e)
        {
            
            game.MoveAll();
            drawBoard();
            CurrGen.Text = "Generation: " + game.GenCnt.ToString();

        }

        private void BtnMain2_Click(object sender, RoutedEventArgs e)
        {

            game.RemoveAll();
            drawBoard();
            CurrGen.Text = "Generation: " + game.GenCnt.ToString();

        }

        private void GameCanvas_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Point click = e.GetPosition(GameCanvas);
            int i = (int)(click.Y / (GameCanvas.Height / GameRows));
            int j = (int)(click.X / (GameCanvas.Width / GameColumns));


            if (game.GetCurr(i, j))
            {
                game.SetCurr(i, j, false);
            }
            else
            {
                game.SetCurr(i, j, true);
            }
            drawCell(i, j);

        }

    }
}
