﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace ConwaysGameOfLife
{
    internal class Game
    {
        Cell[,] Board;
        public int GenCnt { get; set; }

        public Game(int n, int m)
        {
            Board = new Cell[n, m];
            GenCnt = 0;

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    Board[i, j] = new Cell();
                }
            }

        }

        public bool CalcNext(int i, int j)
        {
            int cnt = 0;

            for (int i2 = i - 1; i2 < i + 2; i2++)
            {
                for (int j2 = j - 1; j2 < j + 2; j2++)
                {
                    if (i2 != i ||  j2 != j)
                        if (i2 >= 0 && i2 < Board.GetLength(0) && j2 >= 0 && j2 < Board.GetLength(1))
                            if (Board[i2, j2].CurrGen)
                                cnt++;
                }
            }

            if (Board[i,j].CurrGen)
            {
                if (cnt == 2 || cnt == 3)
                    return true;

                return false;
            }
            else
            {
                if (cnt == 3)
                    return true;
            }

            return false;

        }

        public void CalcAll()
        {
            for (int i = 0; i < Board.GetLength(0); i++)
            {
                for (int j = 0; j < Board.GetLength(1); j++)
                {
                    Board[i,j].NextGen = CalcNext(i, j);
                }
            }

        }

        public void MoveAll()
        {
            CalcAll();

            for (int i = 0; i < Board.GetLength(0); i++)
            {
                for (int j = 0; j < Board.GetLength(1); j++)
                {
                    Board[i, j].CurrGen = Board[i, j].NextGen;
                    Board[i, j].NextGen = false;
                }
            }
            GenCnt++;

        }

        public void RemoveAll()
        {
            for (int i = 0; i < Board.GetLength(0); i++)
            {
                for (int j = 0; j < Board.GetLength(1); j++)
                {
                    Board[i, j].CurrGen = false;
                    Board[i, j].NextGen = false;
                }
            }
            GenCnt = 0;
        }

        public bool GetCurr(int i, int j)
        {
            return Board[i,j].CurrGen;
        }
        public void SetCurr(int i, int j, bool Set)
        {
            Board[i, j].CurrGen = Set;
            Board[i, j].NextGen = CalcNext(i,j);
        }

    }
}
