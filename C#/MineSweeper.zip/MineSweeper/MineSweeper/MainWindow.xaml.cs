﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace MineSweeper
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        int GameColumns;
        int GameRows;
        int mines;
        Game game;
        public MainWindow()
        {
            InitializeComponent();
            newGame();




        }

        public void newGame()
        {
            GameColumns = 15;
            GameRows = 15;
            mines = GameColumns * 2;
            game = new Game(GameColumns, GameRows, mines);
            TxtMines.Text = game.GetHowManyToSuspect().ToString();

            drawBoard();
        }

        private void drawBoard()
        {
            for (int i = 0; i < GameColumns; i++)
            {
                for (int j = 0; j < GameRows; j++)
                {
                    drawCell(i, j);
                }
            }
        }

        private void drawCell(int i, int j)
        {
            int Height = (int)GameCanvas.Height / GameRows;
            int Width = (int)GameCanvas.Width / GameColumns;

            if (game.GetType(i, j) == CellTypes.Hidden)
            {
                Border br = PutRect3D(i * Height, j * Width, Width, Height, 2, Colors.Silver);
                GameCanvas.Children.Add(br);
            }
            else if (game.GetType(i, j) == CellTypes.Suspected)
            {
                Border br = PutRect3D(i * Height, j * Width, Width, Height, 2, Colors.Orange);
                GameCanvas.Children.Add(br);
            }
            else if (game.GetType(i, j) == CellTypes.Open)
            {
                Border br = PutRect3D(i * Height, j * Width, Width, Height, 1, Colors.LightGray);
                GameCanvas.Children.Add(br);

                if (!game.GetBomb(i, j))
                {
                    string str = "*";
                    int sib = game.CountSiblings(i, j);
                    if (sib > 0)
                    {
                        str = sib.ToString();
                        TextBlock txt = new TextBlock();
                        txt.Text = str;
                        txt.FontSize = 14;
                        txt.Foreground = new SolidColorBrush(Colors.Black);
                        Canvas.SetLeft(txt, j * Width + 3);
                        Canvas.SetTop(txt, i * Height);
                        GameCanvas.Children.Add(txt);
                    }
                }
                else
                {
                    br = PutRect3D(i * Height, j * Width, Width, Height, 2, Colors.Red);
                    GameCanvas.Children.Add(br);
                }
            }

        }

        private void GameCanvas_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Point click = e.GetPosition(GameCanvas);
            int i = (int)(click.Y / (GameCanvas.Height / GameRows));
            int j = (int)(click.X / (GameCanvas.Width / GameColumns));


            if (game.GetType(i, j) != CellTypes.Suspected && game.CountSiblings(i, j) == 0)
            {
                OpenAllZeros(i, j);
            }
            game.SetType(i, j, CellTypes.Open);
            drawCell(i, j);

            if (game.GetBomb(i, j))
                MessageBox.Show("Lose");

        }

        private void GameCanvas_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            Point click = e.GetPosition(GameCanvas);
            int i = (int)(click.Y / (GameCanvas.Height / GameRows));
            int j = (int)(click.X / (GameCanvas.Width / GameColumns));

            game.SetType(i, j, CellTypes.Suspected);
            drawCell(i, j);
            TxtMines.Text = game.GetHowManyToSuspect().ToString();

            if (game.GetHowManyToSuspect() == 0)
            {
                if (CheckWin())
                {
                    MessageBox.Show("Win");
                }
                else
                {
                    MessageBox.Show("Lose");
                }
            }
        }

        public bool CheckWin()
        {
            return game.Win();
        }

        private void BtnMain_Click(object sender, RoutedEventArgs e)
        {
            if (BtnMain.Tag.ToString() == "A")
            {
                newGame();
                BtnMain.Tag = "B";
                BtnMain.Content = "Open All";  // the button will show 
            }
            else
            {
                game.OpenAll();
                drawBoard();
                BtnMain.Content = "New Game";
                BtnMain.Tag = "A";

            }
        }



        private Border PutRect3D(double top, double left, double w, double h, int tick, Color c)
        {
            Border br = Rect3D(w, h, tick, c);


            Canvas.SetLeft(br, left); // same like ExBr.SetValue(Canvas.LeftProperty, 0.0);
            Canvas.SetTop(br, top);

            return br;

        }


        private Border Rect3D(double w, double h, int tick, Color c)
        {
            Rectangle r = new Rectangle();

            r.Height = h - 2 * tick;
            r.Width = w - 2 * tick;
            r.Fill = new SolidColorBrush(c);


            Border InnerBr = new Border();
            InnerBr.BorderThickness = new Thickness(0, 0, tick, tick);
            InnerBr.BorderBrush = Brushes.Black;

            InnerBr.Child = r;

            Border ExBr = new Border();
            ExBr.BorderThickness = new Thickness(tick, tick, 0, 0);
            ExBr.BorderBrush = Brushes.White;

            ExBr.Child = InnerBr;
            ExBr.Height = h;
            ExBr.Width = w;

            return ExBr;

        }

        private void OpenAllZeros(int i, int j)
        {
            if (i < 0 || j < 0 || j >= GameColumns || i >= GameRows)
                return;

            CellTypes t = game.GetType(i, j);

            if (t == CellTypes.Open)
                return;

            game.SetType(i, j, CellTypes.Open);
            drawCell(i, j);

            if (game.CountSiblings(i, j) != 0)
                return;

            OpenAllZeros(i + 1, j);
            OpenAllZeros(i - 1, j);
            OpenAllZeros(i, j + 1);
            OpenAllZeros(i, j - 1);
            OpenAllZeros(i + 1, j + 1);
            OpenAllZeros(i - 1, j - 1);
            OpenAllZeros(i - 1, j + 1);
            OpenAllZeros(i + 1, j - 1);


        }
    }
}
