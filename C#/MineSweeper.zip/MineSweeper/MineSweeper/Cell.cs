﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MineSweeper
{
    enum CellTypes
    {
        Hidden,
        Suspected,
        Open
    }
    internal class Cell
    {
        public CellTypes CellType { get; set; }
        public bool Bomb { get; set; }

        public Cell()
        {
            CellType = CellTypes.Hidden;
            this.Bomb = false;
        }
    }

}
