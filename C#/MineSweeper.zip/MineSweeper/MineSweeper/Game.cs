﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MineSweeper
{
    internal class Game
    {
        private Cell[,] Board;
        private Random rnd = new Random();
        private int BombsTotal;
        private int HowManyToSuspect;
        public int HowManyToOpen;

        public int GetHowManyToSuspect()
        {
            return HowManyToSuspect;
        }

        public Game(int n, int m, int mines)
        {
            Board = new Cell[n, m];
            BombsTotal = mines;
            HowManyToSuspect = mines;
            HowManyToOpen = mines;

            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < m; j++)
                {
                    Board[i, j] = new Cell();
                }
            }

            while (mines > 0)
            {
                int x = rnd.Next(n);
                int y = rnd.Next(m);

                if (!Board[x, y].Bomb)
                {
                    Board[x, y].Bomb = true;
                    mines--;
                }
            }
        }

        public int CountSiblings(int i, int j)
        {
            int cnt = 0;

            for (int i2 = i - 1; i2 < i + 2; i2++)
            {
                for (int j2 = j - 1; j2 < j + 2; j2++)
                {
                    if (i2 >= 0 && i2 < Board.GetLength(0) && j2 >= 0 && j2 < Board.GetLength(1))
                        if (Board[i2, j2].Bomb)
                            cnt++;
                }
            }
            return cnt;
        }

        public void SetType(int i, int j, CellTypes t)
        {
            if (Board[i, j].CellType == CellTypes.Open)
                return;

            if (t == CellTypes.Suspected)
            {
                if (Board[i, j].CellType != CellTypes.Suspected)
                {
                    HowManyToSuspect--;
                    if (Board[i, j].Bomb)
                        HowManyToOpen--;
                }

            }
            Board[i, j].CellType = t;


        }

        public CellTypes GetType(int i, int j)
        {
            return Board[i, j].CellType;
        }

        public bool GetBomb(int i, int j)
        {
            return Board[i, j].Bomb;
        }

        public bool GetWrongSuspected(int i, int j)
        {
            if (!Board[i, j].Bomb)
                return true;
            return false;
        }

        internal void OpenAll()
        {
            for (int i = 0; i < Board.GetLength(0); i++)
            {
                for (int j = 0; j < Board.GetLength(1); j++)
                {
                    Board[i, j].CellType = CellTypes.Open;
                }
            }
        }

        public bool Win()
        {
            if (HowManyToSuspect == HowManyToOpen && HowManyToOpen == 0)
                return true;
            return false;
        }

    }
}
